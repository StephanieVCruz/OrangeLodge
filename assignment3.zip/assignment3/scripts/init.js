(function($){

 $(document).ready(function(){



    $('select').material_select();

    $('.scrollspy').scrollSpy();

  	});

	// end of document ready
})(jQuery); // end of jQuery name space
